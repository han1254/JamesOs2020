#include <stdio.h>
#include <string.h>
int main()
{
   
	printf("test\n");
        return 0;
}



